function redirectToPage1(){
    window.location.href = " studentlogin.html";
}
function redirectToPage2(){
    window.location.href = " vendorlogin.html";
}